<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;


Route::get('/', [ProductController::class, 'index'])->name('home');
Route::get('/add-product', [ProductController::class, 'addProduct'])->name('add');

Route::post('/new-product', [ProductController::class, 'newProduct'])->name('new');
Route::post('/update-product', [ProductController::class, 'updateProduct'])->name('update');
Route::get('/manage-product', [ProductController::class, 'manageProduct'])->name('manage');
Route::get('/delete-product/{id}', [ProductController::class, 'deleteProduct'])->name('del');
Route::get('/status-product/{id}', [ProductController::class, 'statusProduct'])->name('stat');
Route::get('/edit-product/{id}', [ProductController::class, 'editProduct'])->name('edit');
