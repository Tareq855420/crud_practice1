Hello World
<?php /**PATH N:\Xampp\htdocs\practice\crud_practice1\resources\views/home/home.blade.php ENDPATH**/ ?>