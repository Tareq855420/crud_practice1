<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row mt-3">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card">
                            <img src="<?php echo e($product['product_image']); ?>" alt="">
                        </div>
                        <div class="card-body">
                            <h5>Product Name: <?php echo e($product['product_name']); ?></h5>
                            <h5>Product Category: <?php echo e($product['product_category']); ?></h5>
                            <h5>Product Brand: <?php echo e($product['brand_name']); ?></h5>
                            <h5>Product Price: <?php echo e($product['product_price']); ?></h5>
                            <h5>Product Description: <?php echo e($product['product_description']); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH N:\Xampp\htdocs\practice\crud_practice1\resources\views/product/home.blade.php ENDPATH**/ ?>