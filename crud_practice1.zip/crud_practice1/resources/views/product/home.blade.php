@extends('master')

@section('title')
    Home
@endsection

@section('body')

    <section class="py-5">
        <div class="container">
            <div class="row mt-3">
                @foreach($product as $product)
                    <div class="col-md-4">
                        <div class="card">
                            <img src="{{ $product['product_image'] }}" alt="">
                        </div>
                        <div class="card-body">
                            <h5>Product Name: {{ $product['product_name'] }}</h5>
                            <h5>Product Category: {{ $product['product_category'] }}</h5>
                            <h5>Product Brand: {{ $product['brand_name'] }}</h5>
                            <h5>Product Price: {{ $product['product_price'] }}</h5>
                            <h5>Product Description: {{ $product['product_description'] }}</h5>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

@endsection
